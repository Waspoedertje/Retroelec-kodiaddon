import xbmcaddon
import xbmcgui
 
addon       = xbmcaddon.Addon()
addonname   = addon.getAddonInfo('name')
 
import xbmc
import os, sys

os.system("/usr/bin/kodi-retroarch.py")
 
